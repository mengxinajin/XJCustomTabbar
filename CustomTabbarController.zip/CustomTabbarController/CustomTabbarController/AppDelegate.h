//
//  AppDelegate.h
//  CustomTabbarController
//
//  Created by 孟现进 on 3.11.20.
//

#import <UIKit/UIKit.h>
#import "BYBJTabbarController.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>

/** window */
@property (nonatomic,strong) UIWindow *window;
/** tab */
@property (nonatomic,strong) BYBJTabbarController *tabVC;
@end

