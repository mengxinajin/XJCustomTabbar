//
//  Mine2ViewController.m
//  CustomTabbarController
//
//  Created by Mac on 9.11.20.
//

#import "Mine2ViewController.h"

@interface Mine2ViewController ()

@end

@implementation Mine2ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我的2";
}

@end
