//
//  Tabbar.h
//  CustomTabbarController
//
//  Created by Mac on 9.11.20.
//

#ifndef Tabbar_h
#define Tabbar_h

#define IS_IPHONEX  ([[UIApplication sharedApplication] statusBarFrame].size.height > 20)
#define Bottom_Margin (IS_IPHONEX? 34:0)
#define KTABBAR_H     (IS_IPHONEX ? 83.0f : 49.0f) //标签高度

#endif /* Tabbar_h */
