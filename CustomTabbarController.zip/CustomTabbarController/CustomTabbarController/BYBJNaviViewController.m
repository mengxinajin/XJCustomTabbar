//
//  BYBJNaviViewController.m
//  CustomTabbarController
//
//  Created by Mac on 9.11.20.
//

#import "BYBJNaviViewController.h"

@interface BYBJNaviViewController ()

@end

@implementation BYBJNaviViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated {
    if (self.viewControllers.count > 0) {

        viewController.hidesBottomBarWhenPushed = YES;
        self.tabBarController.tabBar.hidden = YES;
        self.tabBarController.tabBar.translucent = YES;
    }
    [super pushViewController:viewController animated:animated];
}

@end
