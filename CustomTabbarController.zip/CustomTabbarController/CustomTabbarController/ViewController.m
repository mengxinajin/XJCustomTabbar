//
//  ViewController.m
//  CustomTabbarController
//
//  Created by Mac on 3.11.20.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
