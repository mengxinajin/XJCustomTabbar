//
//  XJCustomTabbar.h
//  CustomTabbarController
//
//  Created by 孟现进 on 3.11.20.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface XJCustomTabbar : UITabBar

@property(nonatomic,assign)NSInteger tabIndex;
@property (nonatomic, copy)  void(^didTapBumpBarBlock)(NSInteger index);


/// 创建tabbar
/// @param backgroundColor 背景颜色
/// @param titArr 标题
/// @param imgArr 图标(未选中)数组
/// @param sImgArr 图标(已选中)数组
/// @param imgSize 未选中图标尺寸
/// @param imgSelectSize 已选中图标尺寸
- (instancetype)initWithBackgroundColor:(UIColor *)backgroundColor titleArr:(NSArray *)titArr imgArr:(NSArray *)imgArr sImgArr:(NSArray *)sImgArr withImgSize:(CGSize)imgSize withSelectImageSize:(CGSize) imgSelectSize;


@end

NS_ASSUME_NONNULL_END
