//
//  XJTabbar.h
//  CustomTabbarController
//
//  Created by 孟现进 on 9.11.20.
//

#ifndef XJTabbar_h
#define XJTabbar_h

#import "UIView+category.h"

#define XJIS_IPHONEX  ([[UIApplication sharedApplication] statusBarFrame].size.height > 20)
#define XJBottom_Margin (XJIS_IPHONEX? 34:0)
#define XJTABBAR_H     (XJIS_IPHONEX ? 83.0f : 49.0f) //标签高度
//屏幕宽高
#define XJScreen_Width [UIScreen mainScreen].bounds.size.width
#define XJScreen_Height [UIScreen mainScreen].bounds.size.height

#define XJWEAK_SELF __weak typeof(self) weakSelf = self
#endif /* XJTabbar_h */
