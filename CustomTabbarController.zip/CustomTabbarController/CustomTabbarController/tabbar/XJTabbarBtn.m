//
//  XJTabbarBtn.m
//  CustomTabbarController
//
//  Created by 孟现进 on 9.11.20.
//

#import "XJTabbarBtn.h"

@implementation XJTabbarBtn

-(void)setImgRect:(CGRect)imgRect{
    _imgRect = imgRect;
}
-(void)layoutSubviews{
    [super layoutSubviews];
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    if (_imgRect.size.width != 0) {
        self.imageView.frame = _imgRect;
    }
    self.titleLabel.frame = CGRectMake(0, self.height - 15 - XJBottom_Margin, self.width, 20);
}



@end
