//
//  XJTabbarBtn.h
//  CustomTabbarController
//
//  Created by 孟现进 on 9.11.20.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface XJTabbarBtn : UIButton

@property(nonatomic,assign)CGRect imgRect;

@end

NS_ASSUME_NONNULL_END
