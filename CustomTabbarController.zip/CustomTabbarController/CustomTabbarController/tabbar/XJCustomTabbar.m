//
//  XJCustomTabbar.m
//  CustomTabbarController
//
//  Created by 孟现进 on 3.11.20.
//

#import "XJCustomTabbar.h"
#import "XJTabbarBtn.h"
#import "UIView+category.h" // 100 *45
@interface XJCustomTabbar ()
{
    CGRect defaultImagRect;
    CGRect selectRect;
    CGFloat centerPace;
    CGFloat defaultPY;
    CGSize _imgSize;
    CGSize _imgSelectSize;
    UIColor *_backgroundColor;
}
@property(nonatomic,strong)XJTabbarBtn *centerBtn;
@property(nonatomic,strong)NSMutableArray *btnArr;
@property(nonatomic,copy)NSArray *titArr;
@property(nonatomic,copy)NSArray *imgArr;
@property(nonatomic,copy)NSArray *sImgArr;
@end
@implementation XJCustomTabbar

- (instancetype)initWithBackgroundColor:(UIColor *)backgroundColor titleArr:(NSArray *)titArr imgArr:(NSArray *)imgArr sImgArr:(NSArray *)sImgArr withImgSize:(CGSize)imgSize withSelectImageSize:(CGSize) imgSelectSize
{
    
    self = [super init];
    if (self) {
        self.backgroundColor = [UIColor blackColor];
        _imgSize = imgSize;
        _imgSelectSize = imgSelectSize;
        _backgroundColor = backgroundColor;
        self.btnArr = [NSMutableArray array];
        
        self.titArr = titArr;
        self.imgArr = imgArr;
        self.sImgArr = sImgArr;
        
        [self creatSubView];
    }
    return self;
}

-(void)creatSubView{
    UIView *backV = [[UIView alloc]initWithFrame:CGRectMake(0, 0, XJScreen_Width, XJTABBAR_H)];
    backV.backgroundColor = _backgroundColor?_backgroundColor:[UIColor blackColor];
    [self addSubview:backV];
    float w = _imgSize.width;
    float h = _imgSize.height;
    //100 *45
    float sw = _imgSelectSize.width;
    float sh = _imgSelectSize.height;
    CGFloat btnW = XJScreen_Width/self.titArr.count;
    selectRect = CGRectMake((btnW-sw)/2, -20, sw, sh);
    defaultImagRect = CGRectMake((btnW-w)/2, 10, w, h);
    centerPace = XJScreen_Width/6.0;
    defaultPY = XJTABBAR_H *0.5;
    for (NSInteger index = 0; index < self.titArr.count; index ++) {
        XJTabbarBtn *btn = [XJTabbarBtn new];
        btn.highlighted = NO;
        [btn setTitle:self.titArr[index] forState:UIControlStateNormal];
        [btn setTitle:self.titArr[index] forState:UIControlStateSelected];
        [btn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
        [btn setImage:[UIImage imageNamed:self.imgArr[index]] forState:UIControlStateNormal];
        btn.titleLabel.font = [UIFont systemFontOfSize:11];
        btn.titleLabel.textAlignment = NSTextAlignmentCenter;
        [btn addTarget:self action:@selector(btnAction:) forControlEvents:UIControlEventTouchUpInside];
        btn.titleLabel.text = self.titArr[index];
        btn.frame = CGRectMake(btnW*index, 0, btnW, XJTABBAR_H);
        btn.imgRect = defaultImagRect;
        btn.center = CGPointMake(centerPace *(index *2 + 1), defaultPY);
        btn.tag = 2020 +index;
        [self addSubview:btn];
        [self.btnArr addObject:btn];
    }
    [self setTabIndex:0];
}

#pragma mark -切换索引
-(void)btnAction:(XJTabbarBtn *)btn{
    for (XJTabbarBtn *indexBtn in self.btnArr) {
        indexBtn.selected = btn.tag == indexBtn.tag ? YES:NO;
    }
//    btn.tag - 2020
    if (self.didTapBumpBarBlock) {
        self.didTapBumpBarBlock(btn.tag - 2020);
    }
    [self setTabIndex:btn.tag - 2020];
   
}
-(void)setTabIndex:(NSInteger)tabIndex{
    _tabIndex = tabIndex;
    [self.btnArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        XJTabbarBtn *btn = obj;
        btn.selected = idx == _tabIndex ? YES:NO;
    }];

    XJTabbarBtn *first = self.btnArr[0];
    XJTabbarBtn *second = self.btnArr[1];
    XJTabbarBtn *third = self.btnArr[2];
    
//    重置
    first.imgRect = defaultImagRect;
    second.imgRect = defaultImagRect;
    third.imgRect = defaultImagRect;
  
     switch (self.tabIndex) {
         case 0:
             first.imgRect = selectRect;
             [first setImage:[UIImage imageNamed:self.sImgArr[0]] forState:UIControlStateNormal];
             [second setImage:[UIImage imageNamed:self.imgArr[1]] forState:UIControlStateNormal];
             [third setImage:[UIImage imageNamed:self.imgArr[2]] forState:UIControlStateNormal];
             break;
         case 1:
             second.imgRect = selectRect;
             [first setImage:[UIImage imageNamed:self.imgArr[0]] forState:UIControlStateNormal];
             [second setImage:[UIImage imageNamed:self.sImgArr[1]] forState:UIControlStateNormal];
             [third setImage:[UIImage imageNamed:self.imgArr[2]] forState:UIControlStateNormal];
             break;
         case 2:
             third.imgRect = selectRect;
             [first setImage:[UIImage imageNamed:self.imgArr[0]] forState:UIControlStateNormal];
             [second setImage:[UIImage imageNamed:self.imgArr[1]] forState:UIControlStateNormal];
             [third setImage:[UIImage imageNamed:self.sImgArr[2]] forState:UIControlStateNormal];
             break;
         default:
             break;
     }
}
#pragma mark -重写hitTest方法，去监听发布按钮的点击，目的是为了让凸出的部分点击也有反应
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {

    //这一个判断是关键，不判断的话push到其他页面，点击发布按钮的位置也是会有反应的，这样就不好了
    //self.isHidden == NO 说明当前页面是有tabbar的，那么肯定是在导航控制器的根控制器页面
    //在导航控制器根控制器页面，那么我们就需要判断手指点击的位置是否在发布按钮身上
    //是的话让发布按钮自己处理点击事件，不是的话让系统去处理点击事件就可以了
    if (self.isHidden == NO) {

        //将当前tabbar的触摸点转换坐标系，转换到发布按钮的身上，生成一个新的点
        CGPoint newP = [self convertPoint:point toView:self.centerBtn];

        //判断如果这个新的点是在发布按钮身上，那么处理点击事件最合适的view就是发布按钮
        if ( [self.centerBtn pointInside:newP withEvent:event]) {
            return self.centerBtn;
        }else{//如果点不在发布按钮身上，直接让系统处理就可以了

            return [super hitTest:point withEvent:event];
        }
    }

    else {//tabbar隐藏了，那么说明已经push到其他的页面了，这个时候还是让系统去判断最合适的view处理就好了
        return [super hitTest:point withEvent:event];
    }
}
#pragma mark -彻底干掉系统UITabBarItem
- (NSArray<UITabBarItem *> *)items {
    return @[];
}
- (void)setItems:(NSArray<UITabBarItem *> *)items {
}
- (void)setItems:(NSArray<UITabBarItem *> *)items animated:(BOOL)animated {
}

@end
