//
//  FirstViewController.m
//  CustomTabbarController
//
//  Created by 孟现进 on 9.11.20.
//

#import "FirstViewController.h"
#import "SecondViewController.h"
#import "AppDelegate.h"

@interface FirstViewController ()

@end

@implementation FirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我的1";
}
- (IBAction)jumpmine2:(id)sender {
    AppDelegate *app = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [app.tabVC changeIndex:1];
    
}
- (IBAction)nextController:(id)sender {
    
    SecondViewController *seVC = [SecondViewController new];
    [self.navigationController pushViewController:seVC animated:YES];
}



@end
