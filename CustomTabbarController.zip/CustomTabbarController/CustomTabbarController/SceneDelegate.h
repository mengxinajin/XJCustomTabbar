//
//  SceneDelegate.h
//  CustomTabbarController
//
//  Created by Mac on 3.11.20.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

