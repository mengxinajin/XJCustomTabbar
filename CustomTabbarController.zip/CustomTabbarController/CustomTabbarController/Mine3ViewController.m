//
//  Mine3ViewController.m
//  CustomTabbarController
//
//  Created by Mac on 9.11.20.
//

#import "Mine3ViewController.h"

@interface Mine3ViewController ()

@end

@implementation Mine3ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我的3";
    
}


@end
