//
//  BYBJTabbarController.m
//  CustomTabbarController
//
//  Created by 孟现进 on 3.11.20.
//

#import "BYBJTabbarController.h"
#import "XJCustomTabbar.h"
#import "UIColor+Hex.h"
#import "FirstViewController.h"
#import "BYBJNaviViewController.h"
#import "Mine2ViewController.h"
#import "Mine3ViewController.h"
@interface BYBJTabbarController ()<UITabBarControllerDelegate>
/** XJCustomTabbar */
@property (nonatomic,strong) XJCustomTabbar *customTabbar;

@end

@implementation BYBJTabbarController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.delegate = self;
    [UIApplication sharedApplication].statusBarStyle=UIStatusBarStyleLightContent;
    [[UITabBar appearance] setTranslucent:NO];
    [self addChildviewControllers];
    [self setValue:self.customTabbar forKey:@"tabBar"];
    XJWEAK_SELF;
    [self.customTabbar setDidTapBumpBarBlock:^(NSInteger index) {
        weakSelf.selectedIndex = index;
    }];
    [self changeIndex:0];//默认0
}

- (void)addChildviewControllers{
//    我的1
    FirstViewController *mine1 = [FirstViewController new];
    mine1.view.backgroundColor = [UIColor cyanColor];
    BYBJNaviViewController *mineNavi1 = [[BYBJNaviViewController alloc] initWithRootViewController:mine1];
    
//    我的2
    Mine2ViewController *mine2 = [Mine2ViewController new];
    mine2.view.backgroundColor = [UIColor redColor];
    BYBJNaviViewController *mineNavi2 = [[BYBJNaviViewController alloc] initWithRootViewController:mine2];
//    我的
    Mine3ViewController *mine3 = [Mine3ViewController new];
    mine3.view.backgroundColor = [UIColor blueColor];
    BYBJNaviViewController *mineNavi3= [[BYBJNaviViewController alloc] initWithRootViewController:mine3];
    
    [self setupChildController:mineNavi1];
    [self setupChildController:mineNavi2];
    [self setupChildController:mineNavi3];
}
- (XJCustomTabbar *)customTabbar{
    NSArray *titArr = @[@"我的1",@"我的2",@"我的3"];
    NSArray *imgArr = @[@"home_tab_mine",@"home_tab_mine",@"home_tab_mine"];
    NSArray *sImgArr = @[@"home_tab_mine_select",@"home_tab_mine_select",@"home_tab_mine_select"];
    if (!_customTabbar) {
        _customTabbar = [[XJCustomTabbar alloc] initWithBackgroundColor:[UIColor blackColor] titleArr:titArr imgArr:imgArr sImgArr:sImgArr withImgSize:CGSizeMake(18, 20) withSelectImageSize:CGSizeMake(100, 45)];
    }
    return _customTabbar;
}
/**  绑定各个控制器, 顺便设置属性 */
- (void)setupChildController:(UIViewController *)vc{
    [self addChildViewController:vc];
}
-(void)changeIndex:(NSInteger)index{
    self.selectedIndex = index;
    self.customTabbar.tabIndex = index;
}

@end
