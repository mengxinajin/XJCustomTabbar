//
//  SecondViewController.m
//  CustomTabbarController
//
//  Created by Mac on 9.11.20.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"第二级";
}


@end
