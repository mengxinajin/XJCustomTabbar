//
//  BYBJTabbarController.h
//  CustomTabbarController
//
//  Created by 孟现进 on 3.11.20.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BYBJTabbarController : UITabBarController

-(void)changeIndex:(NSInteger)index;

@end

NS_ASSUME_NONNULL_END
