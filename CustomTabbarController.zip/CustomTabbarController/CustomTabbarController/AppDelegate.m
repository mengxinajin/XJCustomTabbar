//
//  AppDelegate.m
//  CustomTabbarController
//
//  Created by 孟现进 on 3.11.20.
//

#import "AppDelegate.h"


@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    self.tabVC = [BYBJTabbarController new];
    self.window.rootViewController = self.tabVC;
    
    return YES;
}



@end
